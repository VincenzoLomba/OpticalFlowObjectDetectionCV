
from typing import List
from ultralytics import YOLO
import os
import logger as log
import numpy as np
import cv2
import io
import contextlib
import re

class YBBox:
    def __init__(self, xCenter, yCenter, w, h, confidence):
        self.x = int(xCenter - w / 2)
        self.y = int(yCenter - h / 2)
        self.xCenter = int(xCenter)
        self.yCenter = int(yCenter)
        self.w = int(w)
        self.h = int(h)
        self.confidence = confidence

def performDetection(
        frames: List[np.ndarray],         # List of frames (numpy arrays) to process
        dataFolderPath,                   # Path to the folder containing the YOLOv8 model file
        yoloModelFileName = "yolov8n.pt", # YOLOv8 model file name ("n" stands for "nano", the lightest version)
        confidenceThreshold = 0.75        # Confidence threshold for detection
                                          # (BoundBoxes are shown only if thier confidence is larger w.r.t that threshold)
    ):

    log.log("Loading YOLOv8 model...")

    # Environment variables configuration (for OpenMP and Intel MKL optimization)
    # relevant for optimizing YOLOv8's parallel processing on multi-core CPUs
    os.environ['OMP_NUM_THREADS'] = '14'                        # Limits OpenMP to 14 threads
    os.environ['KMP_AFFINITY'] = 'granularity=fine,compact,1,0' # Thread-core binding strategy (Intel CPUs):
                                                                # granularity=fine : Threads pinned to specific CPU cores
                                                                # compact          : Threads packed together (better cache locality)
                                                                # 1                : enables verbose affinity warnings (0=disabled)
                                                                # 0                : assigns threads consecutively from core 0 and then upwards
                                                                #                    (if 1, assigns threads to cores in a round-robin fashion)

    # Check for YOLOv8 model file presence
    yoloModelPath = dataFolderPath + os.sep + yoloModelFileName
    if not os.path.exists(yoloModelPath):
        log.error(f"File {yoloModelFileName} missing from folder {dataFolderPath}!")

    # Actually loading YOLOv8 model
    model = YOLO(dataFolderPath + os.sep + yoloModelFileName, verbose = False)
    model.fuse() # Layer fusion (optional, but recommended for performance), implies faster inference time) 

    log.log("Performing YOLOv8 detection on all frames...")
    ybboxes = []
    progressLabel = -1
    try:
        for j in range(0, len(frames)):

            frame = frames[j]
            yoloResults = model.predict(
                source  = frame,               # Input frame for detection (numpy array/HWC format)
                conf    = confidenceThreshold, # Minimum confidence score (0.65) to accept detection
                classes = [0],                 # Only detect people (class 0 in COCO dataset)
                verbose = False                # Disable console output (cleaner execution)
            )

            # YOLO results elaboration...
            ybbox = None
            for singleResult in yoloResults:
                boxes = singleResult.boxes.xywh.cpu().numpy()
                confidences = singleResult.boxes.conf.cpu().numpy()
                for box, conf in zip(boxes, confidences):
                    xCenter, yCenter, w, h = box
                    if not ybbox:
                        ybbox = YBBox(xCenter, yCenter, w, h, conf)
                    else:
                        log.log(f"Multiple detections for frame number {j+1}!")
                        break
            ybboxes.append(ybbox)

            # Updating "progress bar"
            progress = (int)(j/len(frames)*100)
            if progress % 10 == 0 and progress != progressLabel:
                progressLabel = progress
                log.log("Progress: " + str(progress) + "%")

    except Exception as e: log.error(f"Error during YOLOv8 detection: {str(e)}")
    finally: return ybboxes

def drawBoundingBoxes(
        frames: List[np.ndarray],
        ybboxes: List[YBBox],
        videoDepths: List[np.ndarray]
    ):

    framesWithBoxes = []
    progressLabel = -1
    progressLabel = -1
    bboxesColor = (0, 255, 0)
    for j in range(0, len(frames)):

        # Updating "progress bar"
        progress = (int)(j/len(frames)*100)
        if progress % 10 == 0 and progress != progressLabel:
            progressLabel = progress
            log.log("Progress: " + str(progress) + "%")
        
        frame = frames[j].copy()
        ybbox = ybboxes[j]
        if not ybbox:
            framesWithBoxes.append(frame)
            continue
        x = ybbox.x
        y = ybbox.y
        w = ybbox.w
        h = ybbox.h
        xCenter = ybbox.xCenter
        yCenter = ybbox.yCenter
        confidence = ybbox.confidence
        depth = videoDepths[j][yCenter, xCenter] if videoDepths is not None else None

        # Drawing bounding box on frame
        cv2.rectangle(frame, (x, y), (x + w, y + h), bboxesColor, 2)
        # Adding confidence label on frame
        label = f"Person: {confidence:.2f}%"
        if depth is not None: label = f"Person: {confidence:.2f}% {depth:.2f}m"
        cv2.putText(
            frame,                   # Input image/frame where text will be drawn
            label,                   # Text string to display (e.g., "Person: 0.95")
            (x, y - 5),              # Text position: 5px above top-left box corner (x,y)
            cv2.FONT_HERSHEY_SIMPLEX, # Font type (clean, sans-serif)
            0.5,                     # Font scale (0.5 = 50% of base size)
            bboxesColor,             # Text color (matches bounding box)
            1                        # Thickness (1px)
        )
        # Adding bounding box center point on frame
        cv2.circle(
            frame,              # Input image/frame where circle will be drawn
            (xCenter, yCenter), # Center coordinates (calculated as x + w//2, y + h//2)
            4,                  # Circle radius in pixels (4px = small visible dot)
            bboxesColor,        # Circle color (matches bounding box color)
            -1                  # Thickness (-1 = filled circle, positive = outline thickness)
        )

        framesWithBoxes.append(frame)

    return framesWithBoxes